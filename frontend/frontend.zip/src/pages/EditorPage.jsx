// src/pages/EditorPage.jsx
import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { io } from 'socket.io-client';
import * as Y from 'yjs';
import { MonacoBinding } from 'y-monaco';
import { useAuth } from '../context/AuthContext';
import Button from '../components/ui/Button';
import '../styles/editor.css';

function EditorPage() {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  // Refs and State Hooks
  const monacoRef = useRef(null);
  const [editor, setEditor] = useState(null);
  const [yDoc, setYDoc] = useState(null);
  const [binding, setBinding] = useState(null);
  const [currentLanguage, setCurrentLanguage] = useState('javascript');
  const [connectedUsers, setConnectedUsers] = useState([]);
  const [isConnected, setIsConnected] = useState(false);
  const [output, setOutput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  // --- UI Handlers ---
  const handleCopyRoomId = () => {
    navigator.clipboard.writeText(roomId);
    // You can replace alert with a toast notification later
    alert(`Room ID "${roomId}" copied to clipboard!`);
  };

  const handleLeaveRoom = () => {
    navigate('/');
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const handleLanguageChange = (e) => {
    const newLanguage = e.target.value;
    setCurrentLanguage(newLanguage);
    if (yDoc) {
      // Set the language on the shared metadata map to sync with others
      yDoc.getMap('metadata').set('language', newLanguage);
    }
  };

  const handleRunCode = async () => {
    if (!editor) return;
    
    setIsExecuting(true);
    const code = editor.getValue();
    
    try {
      // Replace with your actual backend URL
      const response = await fetch('https://codelab-backend-q5m7.onrender.com/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code,
          language: currentLanguage
        })
      });
      
      const result = await response.json();
      setOutput(result.output || result.error || 'No output');
    } catch (error) {
      setOutput(`Error: ${error.message}`);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleEditorDidMount = (editorInstance, monacoInstance) => {
    setEditor(editorInstance);
    monacoRef.current = monacoInstance;
  };

  // --- Main Connection and Syncing Logic ---
  useEffect(() => {
    // IMPORTANT: Replace with your actual Render backend URL
    const socket = io("https://codelab-backend-q5m7.onrender.com");
    const doc = new Y.Doc();
    setYDoc(doc);

    const yMetadata = doc.getMap('metadata');
    yMetadata.observe(event => {
      const newLang = yMetadata.get('language');
      if (newLang && monacoRef.current && editor && newLang !== currentLanguage) {
        setCurrentLanguage(newLang);
        monacoRef.current.editor.setModelLanguage(editor.getModel(), newLang);
      }
    });

    socket.on('connect', () => {
      console.log('Handshake complete! Connected to backend.');
      setIsConnected(true);
      socket.emit('join-room', { 
        roomId, 
        user: {
          id: user?.id,
          name: user?.user_metadata?.username || user?.email
        }
      });
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
    });

    socket.on('user-joined', (userData) => {
      setConnectedUsers(prev => [...prev.filter(u => u.id !== userData.id), userData]);
    });

    socket.on('user-left', (userId) => {
      setConnectedUsers(prev => prev.filter(u => u.id !== userId));
    });

    socket.on('doc-sync', (docState) => {
      Y.applyUpdate(doc, new Uint8Array(docState));
    });

    socket.on('doc-update', (update) => {
      Y.applyUpdate(doc, new Uint8Array(update));
    });

    doc.on('update', (update) => {
      socket.emit('doc-update', { roomId, update });
    });

    return () => {
      socket.disconnect();
      doc.destroy();
    };
  }, [roomId, user]);

  // Effect to create the Monaco Binding once editor and yDoc are ready
  useEffect(() => {
    if (editor && yDoc) {
      const monacoBinding = new MonacoBinding(
        yDoc.getText('monaco'),
        editor.getModel(),
        new Set([editor])
      );
      setBinding(monacoBinding);
    }

    return () => {
      binding?.destroy();
    };
  }, [editor, yDoc]);

  return (
    <div className="editor-container">
      {/* Header */}
      <header className="editor-header">
        <div className="header-left">
          <h1 className="editor-title">CodeLab IDE</h1>
          <div className="connection-status">
            <div className={`status-indicator ${isConnected ? 'connected' : 'disconnected'}`}></div>
            <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
          </div>
        </div>
        
        <div className="header-center">
          <div className="room-info">
            <span className="room-label">Room:</span>
            <code className="room-id">{roomId}</code>
            <Button onClick={handleCopyRoomId} variant="secondary" className="copy-btn">
              Copy ID
            </Button>
          </div>
        </div>

        <div className="header-right">
          <div className="connected-users">
            <span className="users-count">{connectedUsers.length} users</span>
          </div>
          <Button onClick={handleLeaveRoom} variant="secondary">
            Leave Room
          </Button>
          <Button onClick={handleSignOut} variant="secondary">
            Sign Out
          </Button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="editor-toolbar">
        <div className="toolbar-left">
          <select 
            value={currentLanguage} 
            onChange={handleLanguageChange}
            className="language-select"
          >
            <option value="javascript">JavaScript</option>
            <option value="python">Python</option>
            <option value="java">Java</option>
            <option value="cpp">C++</option>
            <option value="c">C</option>
            <option value="html">HTML</option>
            <option value="css">CSS</option>
            <option value="json">JSON</option>
          </select>
        </div>
        
        <div className="toolbar-right">
          <Button 
            onClick={handleRunCode}
            loading={isExecuting}
            className="run-btn"
          >
            {isExecuting ? 'Running...' : 'Run Code'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="editor-main">
        <div className="editor-panel">
          <Editor
            height="100%"
            language={currentLanguage}
            theme="vs-dark"
            onMount={handleEditorDidMount}
            options={{
              fontSize: 14,
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              automaticLayout: true,
            }}
          />
        </div>

        <div className="output-panel">
          <div className="output-header">
            <h3>Output</h3>
            <Button 
              onClick={() => setOutput('')} 
              variant="secondary" 
              className="clear-btn"
            >
              Clear
            </Button>
          </div>
          <div className="output-content">
            <pre>{output || 'Run your code to see output here...'}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditorPage;
